package com.baturin.vpn

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private lateinit var root: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 11, 22)
        window.navigationBarColor = Color.rgb(8, 11, 22)
        showVpnScreen()
    }

    private fun bg(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun showVpnScreen() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(8, 11, 22)) }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 30, 28, 30)
        }
        val title = label("BATURIN VPN", 28f, Color.WHITE, true)
        val subtitle = label("Защищённое подключение", 15f, 0xFF9CA3AF.toInt())
        val spacer = View(this)
        val status = label("●  ГОТОВ К ПОДКЛЮЧЕНИЮ", 13f, 0xFF86EFAC.toInt(), true)
        val connect = TextView(this).apply {
            text = "ПОДКЛЮЧИТЬСЯ"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = bg(0xFF6D28D9.toInt(), 28f)
            setPadding(30, 20, 30, 20)
            setOnClickListener { playPrankVideo() }
        }
        val note = label("Baturin VPN • Demo", 12f, 0xFF6B7280.toInt())

        content.addView(title)
        content.addView(subtitle)
        content.addView(View(this), LinearLayout.LayoutParams(1, 54))
        content.addView(status)
        content.addView(View(this), LinearLayout.LayoutParams(1, 24))
        content.addView(connect, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        content.addView(View(this), LinearLayout.LayoutParams(1, 30))
        content.addView(note)
        root.addView(content, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setContentView(root)
    }

    private fun playPrankVideo() {
        root.removeAllViews()
        root.setBackgroundColor(Color.BLACK)

        val videoView = PlayerView(this).apply {
            useController = false
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
        }
        root.addView(videoView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // Immersive presentation only: Android's Back / power controls remain available.
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)

        val exit = TextView(this).apply {
            text = "✕"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = bg(0x99000000.toInt(), 40f)
            contentDescription = "Закрыть пранк"
            setPadding(12, 8, 12, 8)
            setOnClickListener { closeApp() }
        }
        val exitParams = FrameLayout.LayoutParams(48, 48, Gravity.TOP or Gravity.END)
        exitParams.setMargins(0, 18, 18, 0)
        root.addView(exit, exitParams)

        player = ExoPlayer.Builder(this).build().also { exo ->
            videoView.player = exo
            exo.setMediaItem(MediaItem.fromUri("android.resource://${packageName}/${R.raw.prank_video}"))
            exo.volume = 1f
            exo.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_ENDED) closeApp()
                }
            })
            exo.prepare()
            exo.playWhenReady = true
        }
    }

    private fun closeApp() {
        player?.release()
        player = null
        finishAndRemoveTask()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
