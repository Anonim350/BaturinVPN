# Baturin VPN (prank demo)

Android Studio project for a harmless VPN-lookalike prank:
- Launch screen says **Baturin VPN** and has a Connect button.
- Tapping Connect plays the supplied MP4 with sound in an immersive full-screen player.
- The app closes itself when playback ends.
- A visible close control and Android Back/power controls remain available.

**Important:** this is a visual prank, not a real VPN. It does not create a VPN tunnel, request VPN permissions, prevent exiting, disable the power button, or keep the screen awake against the user's wishes.

## Build without a computer

This project includes a GitHub Actions workflow at `.github/workflows/android.yml`.
1. Create a GitHub repository from your phone.
2. Upload the contents of this project, including the `.github` folder.
3. Open the repository's **Actions** tab and run **Build Baturin VPN APK** (or wait for the push build).
4. Open the completed workflow run, scroll to **Artifacts**, and download `BaturinVPN-debug-apk`.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`.

## Build with Android Studio

Open this folder in Android Studio, sync Gradle, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

The supplied video is bundled at `app/src/main/res/raw/prank_video.mp4`.
